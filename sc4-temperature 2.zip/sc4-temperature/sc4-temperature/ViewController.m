//
//  ViewController.m
//  sc4-temperature
//
//  Created by user on 9/27/17.
//  Copyright © 2017 MyProject. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UISegmentedControl *sgmTemperature;
@property (weak, nonatomic) IBOutlet UILabel *lblValue1;
@property (weak, nonatomic) IBOutlet UISlider *sldValueChanger;
@property (weak, nonatomic) IBOutlet UILabel *lblValue2;
@property (weak, nonatomic) IBOutlet UILabel *freezingPoint;
@property (weak, nonatomic) IBOutlet UILabel *boilingPoint;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.sldValueChanger.minimumValue = 32;
    self.sldValueChanger.maximumValue = 212;
    self.sldValueChanger.value = (self.sldValueChanger.maximumValue - self.sldValueChanger.minimumValue) / 2 + self.sldValueChanger.minimumValue;
    [self.lblValue1 setText:[NSString stringWithFormat:@"Fahrenheit  %.2f",_sldValueChanger.value]];
    [self.lblValue2 setText:[NSString stringWithFormat:@"Celsius  %.2f",(_sldValueChanger.value - 32) * 5/9]];
    [self.freezingPoint setText:[NSString stringWithFormat:@"Freezing Point %.2f", self.sldValueChanger.minimumValue]];
    [self.boilingPoint setText:[NSString stringWithFormat:@"Boiling point %.2f", self.sldValueChanger.maximumValue]];
    [self.freezingPoint setText:[NSString stringWithFormat:@"Freezing Point %.2f Fahrenheit", self.sldValueChanger.minimumValue]];
    [self.boilingPoint setText:[NSString stringWithFormat:@"Boiling point %.2f Fahrenheit", self.sldValueChanger.maximumValue]];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)sgmFormulaChanger:(id)sender {
    
    if(self.sgmTemperature.selectedSegmentIndex == 0){
        self.sldValueChanger.minimumValue = 32;
        self.sldValueChanger.maximumValue = 212;
        self.sldValueChanger.value = (self.sldValueChanger.maximumValue - self.sldValueChanger.minimumValue) / 2 + self.sldValueChanger.minimumValue;
        [self.lblValue1 setText:[NSString stringWithFormat:@"Fahrenheit  %.2f",_sldValueChanger.value]];
        [self.lblValue2 setText:[NSString stringWithFormat:@"Celsius  %.2f",(_sldValueChanger.value - 32) * 5/9]];
        [self.freezingPoint setText:[NSString stringWithFormat:@"Freezing Point %.2f Fahrenheit", self.sldValueChanger.minimumValue]];
        [self.boilingPoint setText:[NSString stringWithFormat:@"Boiling point %.2f Fahrenheit", self.sldValueChanger.maximumValue]];
    } else if (self.sgmTemperature.selectedSegmentIndex == 1){
        self.sldValueChanger.minimumValue = 32;
        self.sldValueChanger.maximumValue = 212;
        self.sldValueChanger.value = (self.sldValueChanger.maximumValue - self.sldValueChanger.minimumValue) / 2 + self.sldValueChanger.minimumValue;
        [self.lblValue1 setText:[NSString stringWithFormat:@"Fahrenheit  %.2f",_sldValueChanger.value]];
        [self.lblValue2 setText:[NSString stringWithFormat:@"Kelvin  %.2f",((_sldValueChanger.value - 32) * 5/9) + 273.15]];
        [self.freezingPoint setText:[NSString stringWithFormat:@"Freezing Point %.2f Fahrenheit", self.sldValueChanger.minimumValue]];
        [self.boilingPoint setText:[NSString stringWithFormat:@"Boiling point %.2f Fahrenheit", self.sldValueChanger.maximumValue]];
        
    } else if (self.sgmTemperature.selectedSegmentIndex == 2){
        self.sldValueChanger.minimumValue = 0;
        self.sldValueChanger.maximumValue = 100;
        self.sldValueChanger.value = (self.sldValueChanger.maximumValue - self.sldValueChanger.minimumValue) / 2 + self.sldValueChanger.minimumValue;
        [self.lblValue1 setText:[NSString stringWithFormat:@"Celsius  %.2f",_sldValueChanger.value]];
        [self.lblValue2 setText:[NSString stringWithFormat:@"Kelvin  %.2f",_sldValueChanger.value + 273.15]];
        [self.freezingPoint setText:[NSString stringWithFormat:@"Freezing Point %.2f Celsius", self.sldValueChanger.minimumValue]];
        [self.boilingPoint setText:[NSString stringWithFormat:@"Boiling point %.2f Celsius", self.sldValueChanger.maximumValue]];
        
    } else if (self.sgmTemperature.selectedSegmentIndex == 3){
        self.sldValueChanger.minimumValue = 0;
        self.sldValueChanger.maximumValue = 100;
        self.sldValueChanger.value = (self.sldValueChanger.maximumValue - self.sldValueChanger.minimumValue) / 2 + self.sldValueChanger.minimumValue;
        [self.lblValue1 setText:[NSString stringWithFormat:@"Celsius  %.2f",_sldValueChanger.value]];
        [self.lblValue2 setText:[NSString stringWithFormat:@"Fahrenheit  %.2f",(_sldValueChanger.value * 9/5) + 32]];
        [self.freezingPoint setText:[NSString stringWithFormat:@"Freezing Point %.2f Celsius", self.sldValueChanger.minimumValue]];
        [self.boilingPoint setText:[NSString stringWithFormat:@"Boiling point %.2f Celsius", self.sldValueChanger.maximumValue]];
        
    } else if (self.sgmTemperature.selectedSegmentIndex == 4){
        self.sldValueChanger.minimumValue = 273.15;
        self.sldValueChanger.maximumValue = 373.15;
        self.sldValueChanger.value = (self.sldValueChanger.maximumValue - self.sldValueChanger.minimumValue) / 2 + self.sldValueChanger.minimumValue;
        [self.lblValue1 setText:[NSString stringWithFormat:@"Kelvin  %.2f",_sldValueChanger.value]];
        [self.lblValue2 setText:[NSString stringWithFormat:@"Celsius  %.2f",_sldValueChanger.value - 273.15]];
        [self.freezingPoint setText:[NSString stringWithFormat:@"Freezing Point %.2f Kelvin", self.sldValueChanger.minimumValue]];
        [self.boilingPoint setText:[NSString stringWithFormat:@"Boiling point %.2f Kelvin", self.sldValueChanger.maximumValue]];
        
    } else if (self.sgmTemperature.selectedSegmentIndex == 5){
        self.sldValueChanger.minimumValue = 273.15;
        self.sldValueChanger.maximumValue = 373.15;
        self.sldValueChanger.value = (self.sldValueChanger.maximumValue - self.sldValueChanger.minimumValue) / 2 + self.sldValueChanger.minimumValue;
        [self.lblValue1 setText:[NSString stringWithFormat:@"Kelvin  %.2f",_sldValueChanger.value]];
        [self.lblValue2 setText:[NSString stringWithFormat:@"Fahrenheit  %.2f",(_sldValueChanger.value - 273.15) * 9/5 + 32]];
        [self.freezingPoint setText:[NSString stringWithFormat:@"Freezing Point %.2f Kelvin", self.sldValueChanger.minimumValue]];
        [self.boilingPoint setText:[NSString stringWithFormat:@"Boiling point %.2f Kelvin", self.sldValueChanger.maximumValue]];
        
    }
    
    
}

- (IBAction)sldValueChanger:(id)sender {
    
    if(self.sgmTemperature.selectedSegmentIndex == 0){
        self.sldValueChanger.minimumValue = 32;
        self.sldValueChanger.maximumValue = 212;
        [self.lblValue1 setText:[NSString stringWithFormat:@"Fahrenheit  %.2f",_sldValueChanger.value]];
        [self.lblValue2 setText:[NSString stringWithFormat:@"Celsius  %.2f",(_sldValueChanger.value - 32) * 5/9]];
    } else if (self.sgmTemperature.selectedSegmentIndex == 1){
        self.sldValueChanger.minimumValue = 32;
        self.sldValueChanger.maximumValue = 212;
        [self.lblValue1 setText:[NSString stringWithFormat:@"Fahrenheit  %.2f",_sldValueChanger.value]];
        [self.lblValue2 setText:[NSString stringWithFormat:@"Kelvin  %.2f",((_sldValueChanger.value - 32) * 5/9) + 273.15]];
    } else if (self.sgmTemperature.selectedSegmentIndex == 2){
        self.sldValueChanger.minimumValue = 0;
        self.sldValueChanger.maximumValue = 100;
        [self.lblValue1 setText:[NSString stringWithFormat:@"Celsius  %.2f",_sldValueChanger.value]];
        [self.lblValue2 setText:[NSString stringWithFormat:@"Kelvin  %.2f",_sldValueChanger.value + 273.15]];
    } else if (self.sgmTemperature.selectedSegmentIndex == 3){
        self.sldValueChanger.minimumValue = 0;
        self.sldValueChanger.maximumValue = 100;
        [self.lblValue1 setText:[NSString stringWithFormat:@"Celsius  %.2f",_sldValueChanger.value]];
        [self.lblValue2 setText:[NSString stringWithFormat:@"Fahrenheit  %.2f",(_sldValueChanger.value * 9/5) + 32]];
    } else if (self.sgmTemperature.selectedSegmentIndex == 4){
        self.sldValueChanger.minimumValue = 273.15;
        self.sldValueChanger.maximumValue = 373.15;
        [self.lblValue1 setText:[NSString stringWithFormat:@"Kelvin  %.2f",_sldValueChanger.value]];
        [self.lblValue2 setText:[NSString stringWithFormat:@"Celsius  %.2f",_sldValueChanger.value - 273.15]];
    } else if (self.sgmTemperature.selectedSegmentIndex == 5){
        self.sldValueChanger.minimumValue = 273.15;
        self.sldValueChanger.maximumValue = 373.15;
        [self.lblValue1 setText:[NSString stringWithFormat:@"Kelvin  %.2f",_sldValueChanger.value]];
        [self.lblValue2 setText:[NSString stringWithFormat:@"Fahrenheit  %.2f",(_sldValueChanger.value - 273.15) * 9/5 + 32]];
    }
    
}


@end
