//
//  ViewController.h
//  sc4-temperature
//
//  Created by user on 9/27/17.
//  Copyright © 2017 MyProject. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

